SAAT <-
function (L, K1, K2, ACD, T, F)
{
    Formula = c("SRKII", "SRKT", "HofferQ", "Haigis", "Shammas")
    
    if(missing(L)) stop ("Axial length is not valid")
    if(missing(K1)) stop ("Keratometry is not valid")
    if(missing(K2)) stop ("Keratometry is not valid")
    if(missing(ACD)) stop ("Anterior chamber depth is not valid")
    if(missing(T)) stop ("Target refraction is not valid")
    if(!(F %in% Formula)) stop("Formula is not supported.")
    
    A0 = -0.111
    A1 = 0.249
    A2 = 0.179	
    SF = 1.67
    Acon1 = 118.8	
    Acon2 = 119.0
    
    K = (K1+K2)/2
    R = 337.5/K
    D = A0 + (A1*ACD) + (A2*L)
    U = T/(1-0.012*T)
    
    if (F == "SRKII") {
        A = Acon1
        P = A - 2.5*L - 0.9*K - 0.7*T
        if (L < 20) {IOL = P+3}
        if (20 <= L | L < 21) {IOL = P+2}
        if (21 <= L | L < 22) {IOL = P+1}
        if (22 <= L | L < 24.5) {IOL = P}
        if (24.5 <= L) {IOL = P-0.5}
    }
    
    else if (F == "SRKT") {
        A = Acon2
        X = A - 2.5*L - 0.9*K - 0.7*T
        if (L < 20) {IOL = X+3}
        if (20 <= L | L < 21) {IOL = X+2}
        if (21 <= L | L < 22) {IOL = X+1}
        if (22 <= L | L < 24.5) {IOL = X}
        if (24.5 <= L) {IOL = X-0.5}
    }
    
    else if (F == "HofferQ"){
        IOL = (1336/(L-ACD-0.05)) - 1.336/(1.336/(K+T/(1-0.012*T))-((ACD+0.05)/1000)) -0.7*T
    }
    else if (F == "Haigis"){
        IOL = 1336/(L-D)-1/((1/K)-(D/1336))-0.7*T
    }
    else if (F == "Shammas"){
        IOL = 1336/(L-0.1*(L-23)-ACD-0.05) - 1/((1.0125/K)-((ACD+0.05)/1336))-0.7*T
    }
    names(IOL) = ""
    return(IOL)
}
