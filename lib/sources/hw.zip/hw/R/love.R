love <- function(x){
  if(x==1){
    print("I'm feeling love, Dr. Mye.")
  }
  else {
    print("I'm looking for my love, Dr. Mye. Would you marry me?")
  }
}
