above <-
function(x, n){
  use <- x < n
  x[use]
}
