fer.ct <-
function(a, b){
  a^-2
}
