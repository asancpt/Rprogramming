Ttest <-
function(x1,x2){
  s1 <- var(x1); s2<- var(x2)
  n1 <- length(x1); n2<-length(x2)

  t <- (mean(x1) - mean(x2))/sqrt(s1/n1+s2/n2)

  df <- (s1/n1 + s2/n2)^2 / (s1^2/n1^2/(n1-1) + s2^2/n2^2/(n2-1))

  p_value <- pt(t,df)
  
  list(t,p_value)
}
