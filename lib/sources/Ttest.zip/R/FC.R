FC <-
function(x3,x4) x4/x3
